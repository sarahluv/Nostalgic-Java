/*******************************************************************************
Name: Sarah Redmon
Date: 8/31/18
Instructor: Ms. Tucker
Class: Gas
Purpose: To show the total amount of KWH used and the total cost for KWH used
*******************************************************************************
*/

import java.util.Scanner;

public class Gas
{
    public static void main (String[] args)
    {
        /* ------------------------------------------------------------------------------
        * This is where all the variables and constants get initialized/doubled at.
        ------------------------------------------------------------------------------
        */
        double chargePerKWH = 9.047e-2;
        double KWHcost;
        double KWHused;
        double refKWHused;
        double dishKWHused;
        double ovenKWHused;
        double microKWHused;
        double coffKWHused;
        double compKWHused;
        double tvKWHused;
        double washdryKWHused;
        double furnaceKWHused;
        double ceilfanKWHused;
        double numRef;
        double numDish;
        double numOven;
        double numMicro;
        double numCoff;
        double numComp;
        double numTV;
        double numWashdry;
        double numFurnace;
        double numCeilfan;
        int refMonthlyUsed = 55;
        int dishMonthlyUsed = 13;
        int ovenMonthlyUsed = 24;
        int microMonthlyUsed = 11;
        int coffMonthlyUsed = 10;
        int compMonthlyUsed = 21;
        int tvMonthlyUsed = 23;
        int washdryMonthlyUsed = 63;
        int furnaceMonthlyUsed = 64;
        int ceilfanMonthlyUsed = 46;
        
        /* ------------------------------------------------------------------------------
        * This is where the scanner gets enable for the user to enter in data.
        ------------------------------------------------------------------------------
        */
        Scanner scan = new Scanner (System.in);
        
        /* ------------------------------------------------------------------------------
        * This is where the user inputs the data that they have.
        ------------------------------------------------------------------------------
        */
        System.out.print ("How many refrigerators do you have? ");
        numRef = scan.nextDouble();
        
        System.out.print ("How many dishwashers do you have? ");
        numDish = scan.nextDouble();
        
        System.out.print ("How many range/ovens do you have? ");
        numOven = scan.nextDouble();
        
        System.out.print ("How many microwaves do you have? ");
        numMicro = scan.nextDouble();
        
        System.out.print ("How many coffee machines do you have? ");
        numCoff = scan.nextDouble();
        
        System.out.print ("How many computers do you have? ");
        numComp = scan.nextDouble();
        
        System.out.print ("How many TVs do you have? ");
        numTV = scan.nextDouble();
        
        System.out.print ("How many washers & dryers do you have? ");
        numWashdry = scan.nextDouble();
        
        System.out.print ("How many furnaces do you have? ");
        numFurnace = scan.nextDouble();
        
        System.out.print ("How many ceiling fans do you have? ");
        numCeilfan = scan.nextDouble();
        
        /* ------------------------------------------------------------------------------
        * Each value the user inputted above gets multiplied by the amount of KWH the appliance uses each month.
        * That amount then gets multiplied by the chargePerKWH (9.047e-2) to get the KWH used by that user.
        ------------------------------------------------------------------------------
        */
        refKWHused = chargePerKWH * (refMonthlyUsed * numRef);
        dishKWHused = chargePerKWH * (dishMonthlyUsed * numDish);
        ovenKWHused = chargePerKWH * (ovenMonthlyUsed * numOven);
        microKWHused = chargePerKWH * (microMonthlyUsed * numMicro);
        coffKWHused = chargePerKWH * (coffMonthlyUsed * numCoff);
        compKWHused = chargePerKWH * (compMonthlyUsed * numComp);
        tvKWHused = chargePerKWH * (tvMonthlyUsed * numTV);
        washdryKWHused = chargePerKWH * (washdryMonthlyUsed * numWashdry);
        furnaceKWHused = chargePerKWH * (furnaceMonthlyUsed * numFurnace);
        ceilfanKWHused = chargePerKWH * (ceilfanMonthlyUsed * numCeilfan);
        
        /* ------------------------------------------------------------------------------
        * Each value the user inputted is now being multiplied by the amount of KWH used monthly by that certain appliance.
        * All the values get added up to get the total KWH used by the user.
        ------------------------------------------------------------------------------
        */
        KWHused = (refMonthlyUsed * numRef) + (dishMonthlyUsed * numDish) + (ovenMonthlyUsed * numOven) + 
        (microMonthlyUsed * numMicro) + (coffMonthlyUsed * numCoff) + (compMonthlyUsed * numComp) + (tvMonthlyUsed * numTV) + 
        (washdryMonthlyUsed * numWashdry) + (furnaceMonthlyUsed * numFurnace) + (ceilfanMonthlyUsed * numCeilfan);
        
        /* ------------------------------------------------------------------------------
        * The KWHused then gets multiplied by the chargePerKWH (9.047e-2) to get the KWHcost.
        ------------------------------------------------------------------------------
        */
        KWHcost = chargePerKWH * KWHused;
        
        /* ------------------------------------------------------------------------------
        * The results are shown here by the information calculated above.
        ------------------------------------------------------------------------------
        */
        System.out.println();
        System.out.println("Refrigerator KWH Used: " + refKWHused);
        System.out.println("Dishwasher KWH Used: " + dishKWHused);
        System.out.println("Range/Oven KWH Used: " + ovenKWHused);
        System.out.println("Microwave KWH Used: " + microKWHused);
        System.out.println("Coffee Machine KWH Used: " + coffKWHused);
        System.out.println("Computer KWH Used: " + compKWHused);
        System.out.println("TV KWH Used: " + tvKWHused);
        System.out.println("Washer & Dryer KWH Used: " + washdryKWHused);
        System.out.println("Furnace KWH Used: " + furnaceKWHused);
        System.out.println("Ceiling Fan KWH Used: " + ceilfanKWHused);
        System.out.println();
        System.out.println("Total KWH Used: " + KWHused);
        System.out.println("Total KWH Cost: " + KWHcost);
    }   
}